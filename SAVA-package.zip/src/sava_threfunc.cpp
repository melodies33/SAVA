#include <Rcpp.h>
using namespace Rcpp;

//[[Rcpp::export]]
double gamldpp(double x) {
  double rr = 0.0722*log(std::max(x,2.0))/x/exp(sqrt(log(x)));
  return rr;
}

double gampower(double x, double z, double s){
  double rr = 1.0/pow(z,x)/s;
  return rr;
}


double gamldpp1p2(double x){
  double rr = 1.0/pow(1.2,x)/5;
  return rr;
}

double gamldppgeo(double x){
  double rr = 1.550546/pow((x+1),2);
  return rr;
}

double gamsava(double j, double z, double s){
  double rr = 1.0/pow((j+1),z)/s;
  return rr;
}

double ldpp(double q, double W, double i, NumericVector lags){
  double re = W*gamldpp(i);
  int ll = lags.size();
  if (ll > 0){
    re += (q - W)*gamldpp(lags[0]);
    if (ll > 1){
      for (int l = 1; l < ll; l++){
        re += q * gamldpp(lags[l]);
      }
    }
  }
  return re;
}

//[[Rcpp::export]]
double threldpp(double q, double W, double index, NumericVector rej){
  NumericVector cc = rej[rej < index];
  cc = index - cc;
  return ldpp(q, W, index, cc);
}


//[[Rcpp::export]]
double threpower(double q, double W, double index, NumericVector rej, double z, double s){
  // double W = q/2;
  NumericVector cc = rej[rej < index];
  cc = index - cc;
  double re = W*gampower(index, z, s);
  int ll = cc.size();
  if (ll > 0){
    re += (q - W)*gampower(index, z, s);
    if (ll > 1){
      for (int l = 1; l < ll; l++){
        re += q * gampower(index, z, s);
      }
    }
  }
  return re;
}

double gamsaff(double i){
  return 0.4374901658/pow(i, 1.6);
}

double sffr(double q, double lamb, double w0, NumericVector lags, double index){
  double l = lags.length();
  double re = w0*gamsaff(lags[0]);
  if (l > 1){
    re += (q - w0)*gamsaff(lags[1]);
    if (l > 2){
      for (int ll = 2; ll < l; ll++){
        re += q*gamsaff(lags[ll]);
      }
    }
  }
  re = std::min(lamb, re*(1 - lamb));
  return re;
}

NumericVector csaff(double index, NumericVector cvec, NumericVector tau){
  int taulen = tau.length();
  NumericVector ree(1 + taulen);
  for (int i = 0; i < index - 1; i++){
    ree[0] += cvec[i];
  }
  if (taulen > 0){
    for (int j = 0; j < taulen; j++){
      if (tau[j] + 1 < index){
        for (int k = tau[j]; k < index - 1; k++){
          ree[j+1] += cvec[k];
        }
      }else{
        ree[j+1] = 0;
      }
    }
  }
  return ree;
}

//[[Rcpp::export]]
double thresaff(double q, double w0, double index, NumericVector rejvec, NumericVector cvec, double lamb){
  NumericVector cc = rejvec[rejvec < index];
  NumericVector cff = csaff(index, cvec, cc);
  NumericVector rejlag = index - cff;
  double thre;
  int ll = cc.length();
  if (ll > 0){
    for (int k = 1; k < (ll + 1); k++){
      rejlag[k] = rejlag[k] - cc[k - 1];
    }
  }
  thre= sffr(q, lamb, w0, rejlag, index);
  return thre;
}


//[[Rcpp::export]]
double threaddis(double q, double w0, double index, NumericVector rejvec, NumericVector cvec, double sindex, NumericVector kstar, double lamb, double tau){
  NumericVector cc = rejvec[rejvec < index];
  NumericVector cff = csaff(index, cvec, cc);
  NumericVector rejlag = sindex - cff;
  int ll = cc.length();
  if (ll > 0){
    for (int k = 1; k < (ll + 1); k++){
      rejlag[k] = rejlag[k] - kstar[k - 1];
    }
  }
  double l = rejlag.length();
  double re = w0*gamsaff(rejlag[0] + 1);
  if (l > 1){
    re += (q - w0)*gamsaff(rejlag[1] + 1);
    if (l > 2){
      for (int ll = 2; ll < l; ll++){
        re += q*gamsaff(rejlag[ll] + 1);
      }
    }
  }
  re = std::min(lamb, re*(tau - lamb));
  return re;
}

//[[Rcpp::export]]
double thresaffagg(double q, double w0, double index, NumericVector rejvec, NumericVector cvec, double lamb){
  NumericVector cc = rejvec[rejvec < index];
  NumericVector cff = csaff(index, cvec, cc);
  NumericVector rejlag = index - cff;
  int inverseorder;
  double thre;
  int ll = cc.length();
  if (ll > 0){
    for (int k = 1; k < (ll + 1); k++){
      if (k >= 2){
        inverseorder = sum(cc[Range(0, k - 2)] > cc[k - 1]);
        rejlag[k] = rejlag[k] - cc[k - 1] - inverseorder;
      }else{
        rejlag[k] = rejlag[k] - cc[k - 1];
      }
    }
  }
  thre= sffr(q, lamb, w0, rejlag, index);
  return thre;
}
