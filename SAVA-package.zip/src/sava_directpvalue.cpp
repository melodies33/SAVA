#include <Rcpp.h>
using namespace Rcpp;


double lambda(double alpha, double t){
  double re = 8*log(2.0/alpha)/(t * log(t + 1));
  re = std::min(1.0, sqrt(re));
  return re;
}

double msprt(double sn, int n){
  double re = exp(n * n * sn * sn/2/(n+1))/sqrt(n+1);
  return re;
}

double lambdaplus(double alpha, double sigmasq, double t, double m){
  double re = sqrt(2*log(2/alpha)/sigmasq/t/log(t + 1));
  re = std::min(0.5/m, re);
  return re;
}

double lambdaminus(double alpha, double sigmasq, double t, double m){
  double re = sqrt(2*log(2/alpha)/sigmasq/t/log(t + 1));
  re = std::min(0.5/(1 - m), re);
  return re;
}

// [[Rcpp::export]]
double oracsprt(double realmu, double muzero, double meansamp, double n){
  double re = exp(n*(realmu - muzero)*(2*meansamp - muzero - realmu)/2);
  return re;
}

// [[Rcpp::export]]
double falphaplus(double alpha, NumericVector sampvec, double bound, double t, double gamma){
  NumericVector lamvec(t);
  double re;
  for (int i = 0; i < t; i++){
    lamvec[i] = lambda(alpha, (double)(i + 1));
  }
  re = sum(lamvec * sampvec) - log(2.0/alpha) - sum(pow(lamvec, 2))*pow(bound, 2)/8.0 - sum(lamvec)*gamma;
  return re;
}


// [[Rcpp::export]]
double falphaminus(double alpha, NumericVector sampvec, double bound, double t, double gamma){
  NumericVector lamvec(t);
  double re;
  for (int i = 0; i < t; i++){
    lamvec[i] = lambda(alpha, (double)(i + 1));
  }
  re = sum(lamvec * sampvec) + log(2.0/alpha) + sum(pow(lamvec, 2))*pow(bound, 2)/8.0 + sum(lamvec)*gamma;
  return re;
}
